package com.yohendrakumar.technologyassessment.utils;

public class AppConstatant {
    public static final String API_KEY = "2IYnGJNHeRnfdTGo4E5DabaLWnM1tEpy";
}
